/** An interface that has a getName method */
export interface LayerElement {
  getName: () => string;
}
